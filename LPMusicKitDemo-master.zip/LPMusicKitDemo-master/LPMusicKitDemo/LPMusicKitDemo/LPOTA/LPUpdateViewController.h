//
//  LPUpdateViewController.h
//  upnpxTest
//
//  Created by sunyu on 2019/10/24.
//  Copyright © 2019 wiimu. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LPUpdateViewController : UIViewController
@property(nonatomic,copy)NSString *uuid;
@end

NS_ASSUME_NONNULL_END
