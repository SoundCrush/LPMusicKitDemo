//
//  AppDelegate.h
//  LPMusicKitDemo
//
//  Created by sunyu on 2020/5/9.
//  Copyright © 2020 sunyu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

