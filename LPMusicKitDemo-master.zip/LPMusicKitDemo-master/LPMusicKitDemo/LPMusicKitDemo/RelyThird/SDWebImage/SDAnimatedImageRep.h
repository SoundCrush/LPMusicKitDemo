#import "SDWebImageCompat.h"
#if SD_MAC
@interface SDAnimatedImageRep : NSBitmapImageRep
@end
#endif
