//
//  LPAlexaKit.h
//  LPAlexaKit
//
//  Created by sunyu on 2019/7/23.
//  Copyright © 2019 Linkplay. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <LPAlexaKit/LPAlexaManager.h>
#import <LPAlexaKit/LPAlexaSplashView.h>
#import <LPAlexaKit/LPAlexaLoginView.h>

//! Project version number for LPAlexaKit.
FOUNDATION_EXPORT double LPAlexaKitVersionNumber;

//! Project version string for LPAlexaKit.
FOUNDATION_EXPORT const unsigned char LPAlexaKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LPAlexaKit/PublicHeader.h>


