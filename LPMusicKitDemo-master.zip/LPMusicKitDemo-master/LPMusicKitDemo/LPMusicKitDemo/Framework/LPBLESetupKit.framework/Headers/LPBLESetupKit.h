//
//  LPBLESetupKit.h
//  LPBLESetupKit
//
//  Created by 许一宁 on 2019/7/23.
//  Copyright © 2019 Linkplay. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <LPBLESetupKit/LPBLEEnum.h>
#import <LPBLESetupKit/LPBLEManager.h>
#import <LPBLESetupKit/LPPeripheral.h>

//! Project version number for LPBLESetupKit.
FOUNDATION_EXPORT double LPBLESetupKitVersionNumber;

//! Project version string for LPBLESetupKit.
FOUNDATION_EXPORT const unsigned char LPBLESetupKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LPBLESetupKit/PublicHeader.h>


