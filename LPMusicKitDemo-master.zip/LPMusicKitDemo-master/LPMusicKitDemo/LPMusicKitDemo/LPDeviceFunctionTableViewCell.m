//
//  LPDeviceFunctionTableViewCell.m
//  LPMusicKitDemo
//
//  Created by sunyu on 2020/9/9.
//  Copyright © 2020 sunyu. All rights reserved.
//

#import "LPDeviceFunctionTableViewCell.h"

@implementation LPDeviceFunctionTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
